package com.andrescallejas.RepuestosAutomotrices;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploApplication implements CommandLineRunner{

    public static void main(String[] args) {
        SpringApplication.run(EjemploApplication.class, args);
    }
    @Override
    public void run(String... args) throws Exception {
        System.out.println("TEST API FUNCIONANDO...");
    }
}
